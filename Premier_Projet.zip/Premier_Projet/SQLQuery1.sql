create database EMP;

create table Admin 
(
	Cin varchar(15) primary key,
	Email varchar(50),
	Pass varchar(50)
);
INSERT into admin VALUES('F661540','ayoubbellahcen10@gmail.com','1234');


create table Region 
(
	Idr int primary key,
	Reg varchar(50)
);
INSERT into Region VALUES(1,'Tanger-T�touan-Al Hoce�ma');
INSERT into Region VALUES(2,'Oriental');
INSERT into Region VALUES(3,'F�s-Mekn�s');
INSERT into Region VALUES(4,'Rabat-Sal�-K�nitra');
INSERT into Region VALUES(5,'B�ni Mellal-Kh�nifra');
INSERT into Region VALUES(6,'Casablanca-Settat');
INSERT into Region VALUES(7,'Marrakech-Safi');
INSERT into Region VALUES(8,'Dr�a-Tafilalet');
INSERT into Region VALUES(9,'Souss-Massa');
INSERT into Region VALUES(10,'Guelmim-Oued Noun');
INSERT into Region VALUES(11,'La�youne-Sakia El Hamra');
INSERT into Region VALUES(12,'Dakhla-Oued Ed-Dahab');

create table Localisation 
(
	Idl int primary key AUTO_INCREMENT ,
	Ville varchar(50),
	idre int,
	foreign key (idre) references Region(Idr)
);

INSERT into Localisation ( `Ville`, `idre`) VALUES('Tanger-Asilah',1);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Chefchaouen',1);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Hoceima',1);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Tetouan',1);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Oujda',2);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Nador',2);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Berkane',2);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Fes',3);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Taza',3);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Meknes',3);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Ifrane',3);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Rabat',4);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Sale',4);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Kenitra',4);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Beni Mellal',5);
INSERT into Localisation ( `Ville`, `idre`)  VALUES('Khenifra',5);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Khouribga',5);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Settat',6);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Casablanca',6);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Mohammedia',6);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Marrakech',7);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Kelaa des Sraghna',7);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Safi',7);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Ouarzazate',8);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Zagora',8);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Errachidia',8);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Midelt',8);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Agadir Ida-Outanane',9);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Taroudant',9);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Tata',9);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Guelmim',10);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Sidi Ifni',10);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Tan-Tan',10);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Laayoune',11);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Tarfaya',11);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Boujdour',11);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Aousserd',12);
INSERT into Localisation ( `Ville`, `idre`) VALUES('Oued Ed-Dahab',12);



create table Proffession 
(
	Idp int primary key AUTO_INCREMENT,
	Prof varchar(50)
);

INSERT into Proffession ( `Prof`) VALUES('Plombier');
INSERT into Proffession ( `Prof`) VALUES('Macon');
INSERT into Proffession ( `Prof`) VALUES('Plafonnier');
INSERT into Proffession ( `Prof`) VALUES('soudeur');
INSERT into Proffession ( `Prof`) VALUES('Menuisier');

create table Client 
(
	Cin varchar(15) primary key,
	Email varchar(50),
	Tel varchar(50),
	Pass varchar(50),
	Prenom varchar(50),
	Nom varchar(50),
	ImgP varchar(50),
	Idlo int,
	act boolean,
	foreign key (Idlo) references Localisation(Idl)
	
);

create table Ouvrier 
(
	Cin varchar(15) primary key,
	Email varchar(50),
	Tel varchar(50),
	Pass varchar(50),
	Prenom varchar(50),
	Nom varchar(50),
	ImgP Text,
	Imgc Text,
	Idlo int,
	act boolean,
	foreign key (Idlo) references Localisation(Idl),
	Idpr int,
	foreign key (Idpr) references Proffession(Idp),
	des Text
);

